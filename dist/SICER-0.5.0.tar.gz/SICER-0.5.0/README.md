# SICER-2
Redesigned and improved version of bioinformatics tool SICER
